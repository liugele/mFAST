
function  [jacobi_matrix]=Bulid_jacobi_matrix_cells(rays,cells_model,success_index,flag)
%##########################################################################
% construct the jacobi matrix
% 2021 06 01
% use the grid intercept code to calcute the intersection points
% first two successive points are extract for the raypth (x0,y0),(x1,y1);
% then determine whether this segment is within the same cell or not 
% if it is not, use the grid_interectp code to compute intersection points
% 
% % 2-dimensional example
% Rays = zeros(Nrays, 2, 2);
% Rays(:,1,1) = x0;  N����������x,
% Rays(:,2,1) = x1;  N�������յ��x,  Rays(:,:,1) ����յ��x

% Rays(:,1,2) = y0;  N����������y,
% Rays(:,2,2) = y1;  N�������յ��y,  Rays(:,:,2) ����յ��y
%##########################################################################
% cells_model.num_cell_x=num_cell_x;
% cells_model.num_cell_z=num_cell_z;
% cells_model.cell_dx=cell_dx;
% cells_model.cell_dz=cell_dz;
% cells_model.Cell_vel=Cell_vel;
% cells_model.x=x1;
% cells_model.z=z1;
% modification
% 2021 06 10
% consider the effectiveness of the rays.
%##########################################################################


%##########################################################################
x=cells_model.x;
z=cells_model.z;
dx_of_cell=cells_model.cell_dx;
dz_of_cell=cells_model.cell_dz;
% grid lines for cells
Xg = x;
Zg = z;
%
x_orig=x(1);
z_orig=z(1);

num_cell_x=cells_model.num_cell_x;
num_cell_z=cells_model.num_cell_z;
Ncells=num_cell_x*num_cell_z;
%##########################################################################


%##########################################################################
nrays=size(rays,2);
num_effective_rays=sum(success_index);
jacobi_matrix=zeros(num_effective_rays,Ncells);
i_effective_ray=0;
%##########################################################################


for iray=1:nrays
    
    if success_index(iray)==1 
        i_effective_ray=i_effective_ray+1;        
        if flag==1
            disp(['ray ',num2str(iray),' of ',num2str(nrays),' is effective']);
        end      
        
        %##################################################################
        % raypath for current ray
        ray=rays(iray);
        x_cor=ray.x;
        z_cor=ray.z;        
        num_points=length(x_cor);
        num_segments=num_points-1;
        
        for isegment=1:num_segments
            
           
            
            
            %###############################################################
            % staring point and end point for current segment
            x1=x_cor(isegment);  z1=z_cor(isegment);
            x0=x_cor(isegment+1);z0=z_cor(isegment+1);            
            dl=sqrt((x1-x0)*(x1-x0)+(z1-z0)*(z1-z0));            
            %##############################################################
            % 
           
            [is_same_cell]=is_segment_within_a_cell(x0,x1,z0,z1,x_orig,z_orig,dx_of_cell,dz_of_cell);         
            
            if  is_same_cell==1
                % 
                xm=(x0+x1)/2; zm=(z1+z0)/2;
                ix_cell=fix((xm-x_orig)/dx_of_cell)+1;
                iz_cell=fix((zm-z_orig)/dz_of_cell)+1;
                Cell_1d=(iz_cell-1)*(num_cell_x)+ix_cell;
                jacobi_matrix(i_effective_ray,Cell_1d)=jacobi_matrix(i_effective_ray,Cell_1d)+dl;
            else
                % compute intersection
                
                %##############################################################
                % create the Rays matrix to fit the grid intersection Code
                Nrays=1;
                Rays = zeros(Nrays, 2, 2);
                Rays(:,1,1) = x0;
                Rays(:,2,1) = x1;
                Rays(:,1,2) = z0;
                Rays(:,2,2) = z1;
                
                [Segment_Lengths, Cells, Valid_Intersections, Intersections] = find_ray_grid_intersections(Rays, Xg, Zg);
                
                % find the effective index
                id_of_valid_intersections = find(Valid_Intersections(1,:) > 0);
                num_valid_intersections=length(id_of_valid_intersections);
                num_sub_segment=num_valid_intersections-1;
                
                for isub_segment=1:num_sub_segment
                    
                    idx0=id_of_valid_intersections(isub_segment);
                    
                    seg_x0=Intersections(1,idx0,1);
                    seg_x1=Intersections(1,idx0+1,1);                    
                    seg_z0=Intersections(1,idx0,2);
                    seg_z1=Intersections(1,idx0+1,2);                 
                    
                    
                    xm=(seg_x0+seg_x1)/2; zm=(seg_z1+seg_z0)/2;                    
                    ix_cell=fix((xm-x_orig)/dx_of_cell)+1;
                    iz_cell=fix((zm-z_orig)/dz_of_cell)+1;           

                    Cell_1d=(iz_cell-1)*(num_cell_x)+ix_cell;
                    
                    dl=sqrt((seg_x1-seg_x0)*(seg_x1-seg_x0)+(seg_z1-seg_z0)*(seg_z1-seg_z0));
                    
                    jacobi_matrix(i_effective_ray,Cell_1d)=jacobi_matrix(i_effective_ray,Cell_1d)+dl;
                    
                end
            end
        end
    end
end
disp(['There are  ',num2str(i_effective_ray),' of ',num2str(nrays),' that are effective']);
end

