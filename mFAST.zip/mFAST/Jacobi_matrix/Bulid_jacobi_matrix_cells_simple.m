function  [jacobi_matrix]=Bulid_jacobi_matrix_cells_simple(rays,cells_model,success_index,flag)
%##########################################################################
% 2021 06 18 a simple version of the code used to bulid the jacobi matrix
% This code is used when the segment is short 
%##########################################################################

%##########################################################################
x=cells_model.x;
z=cells_model.z;
dx_of_cell=cells_model.cell_dx;
dz_of_cell=cells_model.cell_dz;
x_orig=x(1);
z_orig=z(1);
num_cell_x=cells_model.num_cell_x;
num_cell_z=cells_model.num_cell_z;
Ncells=num_cell_x*num_cell_z;
%##########################################################################

%##########################################################################
nrays=size(rays,2);
num_effective_rays=sum(success_index);
jacobi_matrix=zeros(num_effective_rays,Ncells);
i_effective_ray=0;
%##########################################################################
for iray=1:nrays    
    if success_index(iray)==1
        i_effective_ray=i_effective_ray+1;
        if flag==1
            disp(['ray ',num2str(iray),' of ',num2str(nrays),' is effective']);
        end        
        %##################################################################
        % extract current raypath
        ray=rays(iray);
        x_cor=ray.x;
        z_cor=ray.z;
        num_points=length(x_cor);
        num_segments=num_points-1;        
        for isegment=1:num_segments            
            %##############################################################            
            % staring point and end point for current segment            
            x1=x_cor(isegment);  z1=z_cor(isegment);
            x0=x_cor(isegment+1);z0=z_cor(isegment+1);
            dl=sqrt((x1-x0)*(x1-x0)+(z1-z0)*(z1-z0));            
            
            % calculate the middle point
            xm=(x0+x1)/2; zm=(z1+z0)/2;
            ix_cell=fix((xm-x_orig)/dx_of_cell)+1;
            iz_cell=fix((zm-z_orig)/dz_of_cell)+1;
            
            % change into one dimensional index
            Cell_1d=(iz_cell-1)*(num_cell_x)+ix_cell;
            
            % segment lenght from the same raypath and within the same cell
            % are add togather.
            jacobi_matrix(i_effective_ray,Cell_1d)=jacobi_matrix(i_effective_ray,Cell_1d)+dl;            
        end
    end
end
disp(['There are  ',num2str(i_effective_ray),' of ',num2str(nrays),' that are effective']);
end

