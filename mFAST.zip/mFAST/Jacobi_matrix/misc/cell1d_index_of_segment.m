
function cell_1d=cell1d_index_of_segment(x0,x1,z0,z1,x_orig,z_orig,dx_of_cell,dz_of_cell)
% 对于一个包含在一个Cell里边的射线段，确定其在哪个Cell内，并计算该Cell的一维标识号

xm=(x0+x1)/2; zm=(z1+z0)/2;
ix_cell=fix((xm-x_orig)/dx_of_cell)+1;
iz_cell=fix((zm-z_orig)/dz_of_cell)+1;

cell_1d=(iz_cell-1)*(num_cell_x-1)+ix_cell;

end

