
function [is_same_cell]=is_segment_within_a_cell(x0,x1,z0,z1,x_orig,z_orig,dx_of_cell,dz_of_cell)

% 2021 06 09
% modified to consider the special case when one of the end point is
% located on grid lines.
% if it is the case, then they are in the same cell

case1=mod(x0-x_orig,dx_of_cell)==0;
case2=mod(x1-x_orig,dx_of_cell)==0;
case3=mod(z0-z_orig,dz_of_cell)==0;
case4=mod(z0-z_orig,dz_of_cell)==0;

if case1||case2||case3||case4
    is_same_cell=1;
else    
    % 计算x0 z0所在Cell
    ix0_cell=fix((x0-x_orig)/dx_of_cell)+1;
    iz0_cell=fix((z0-z_orig)/dz_of_cell)+1;
    
    % 计算x1 z1所在Cell
    ix1_cell=fix((x1-x_orig)/dx_of_cell)+1;
    iz1_cell=fix((z1-z_orig)/dz_of_cell)+1;    
    
    if ix0_cell==ix1_cell&&iz0_cell==iz1_cell
        is_same_cell=1;
    else
        is_same_cell=0;
    end   
    
end
end