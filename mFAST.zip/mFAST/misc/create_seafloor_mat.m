function seafloor=create_seafloor_mat(txtfilename,xmin,xmax)

% 根据海底文件创建包含海底深度信息的结构体
data=load(txtfilename);
x=data(:,1)*1000;
z=data(:,2)*1000*-1;
if x(1)>xmin
    x(1)=xmin;
end

if x(end)<xmax
    x(end)=xmax;
end
seafloor.x=x;
seafloor.z=z;
end


