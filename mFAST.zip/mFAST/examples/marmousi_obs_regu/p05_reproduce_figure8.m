
% #########################################################################
% 2022 01 17
% compare the final model to the initial gradient model
% #########################################################################


figure;

inversion_result=[matfile_for_inversion,'_iter_',num2str(1),'.mat'];
load(inversion_result);

subplot(221);
imagesc(initial_model.vel); colormap jet;colorbar; title('initial model');
xlabel('x/m');ylabel('z/m');

subplot(222);
imagesc(nodes_model.vel,[1500,4000]);  colormap jet;colorbar; title('inverted model');
inversion_result=[matfile_for_inversion,'_iter_',num2str(10),'.mat'];
load(inversion_result);
xlabel('x/m');ylabel('z/m');

subplot(223);
velsmo=velsmooth(nodes_model.vel,nodes_model.x,nodes_model.z,200);
imagesc(velsmo,[1500,4000]);  colormap jet;colorbar; title('inverted model after smoothing');
xlabel('x/m');ylabel('z/m');


subplot(224);
load('marmousi_forward_model.mat');
imagesc(forward_model.vel);  colormap jet;colorbar; title('groundtruth model');
xlabel('x/m');ylabel('z/m');