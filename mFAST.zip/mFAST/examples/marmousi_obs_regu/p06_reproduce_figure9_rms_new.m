
rms_time=zeros(10,1);
for iter=1:10      
    inversion_result=['new_marmousi_syn2_obs_inversion__iter_',num2str(iter)];
    load(inversion_result);    
    plot(t_xxx,t_cal-t_obs,'.');   
    rms_time(iter)=rms(t_cal-t_obs);
    title(['Iteration : ',num2str(iter)]);      
    pause;   
end

figure;
plot(1:10,rms_time,'.');
xlabel('Iterations');
ylabel('RMS');
hold on;
plot(1:10,rms_time,'r');
xlabel('Iterations');
ylabel('RMS');






