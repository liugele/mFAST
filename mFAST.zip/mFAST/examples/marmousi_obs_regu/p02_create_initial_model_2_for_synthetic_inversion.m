%##########################################################################
%##########################################################################
% 2021 06 18
% 2021 07 11
%##########################################################################

outmatfile='marmousi_syn2_obs_initial_model_gradient.mat';
%##########################################################################
% Create a initial model for inversion
load('marmousi_true_dg10.mat');
vmin=min(min(vel));
vmax=max(max(vel));
vel=zeros(nz,nx);
for iz=1:nz
    zz=z(iz);
    vv=vmin+zz/z(end)*(vmax-vmin);
    vel(iz,:)=vv;
end   

figure; imagesc(x,z,vel);colormap jet;title('inital_model model');
initial_model.dx=dx;
initial_model.dz=dz;
initial_model.x=x;
initial_model.z=z;
initial_model.vel=vel;
initial_model.nx=length(x);
initial_model.nz=length(z);
save(outmatfile,'initial_model');
%##########################################################################




