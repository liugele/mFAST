% 2021 07 12
load('synthetic_rays.mat');
load('marmousi_forward_model.mat');

imagesc(forward_model.x,forward_model.z,forward_model.vel);colormap jet;colorbar;
hold on;
nrays=length(success_index);
for iray=1:1:nrays  
    
     ray=rays(iray);
     x_cor=ray.x;
     z_cor=ray.z;
     plot(x_cor,z_cor,'b.');
end

%##########################################################################

% after QC save the rays into the fbpick.txt file.

for iray=1:1:nrays
    
    
     ray=rays(iray);
     x_cor=ray.x;
     z_cor=ray.z;
     plot(x_cor,z_cor,'b.');
end
