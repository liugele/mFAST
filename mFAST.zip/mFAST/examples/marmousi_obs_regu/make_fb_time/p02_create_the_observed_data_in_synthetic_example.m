%##########################################################################
% 2021 06 18 
% create this script
% 2021 07 11 
% set the geometry file in the general way
% create ray_geometry for synthetic studies
%##########################################################################
outmatfile='synthetic_rays.mat';
% load the source-receiver configuration file
load('marmousi_rays_geom_syn2_obs.mat');
% load the forward model 
load('marmousi_forward_model.mat');

% 射线追踪参数
flag=1;
raytracing_par.dstep=10;        
raytracing_par.max_steps=1000;


%##########################################################################
[tcal,success_index,rays]=mFAST_raytracing(forward_model,rays_geom,raytracing_par,flag);


%##########################################################################
% QC
%         %  把当前射线的射线路径保存到一个structure中
%         ray.x=ray_x;
%         ray.z=ray_z;
%         ray.xs=xs;  % OBS x
%         ray.zs=zs;  % OBS x
%         ray.xr=cur_xr;
%         ray.zr=cur_zr;
%         ray.t_cal=cur_t_cal;
%         ray.t_obs=cur_t_obs;
%         ray.success=is_success;
save(outmatfile,'rays');







