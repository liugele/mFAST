%##########################################################################
% 2021 06 18 
% create this script
% 2021 07 11 
% set the geometry file in the general way
% create ray_geometry for synthetic studies
% 2022 01 17
%##########################################################################
matfile='marmousi_rays_geom_syn2_obs.mat';

% create the shot position array;
sours_x=1000:500:9000;
num_sours=length(sours_x);
sours_z=ones(1,num_sours)*1500;

% fixed receicers position
reces_x=(100:50:9000);
num_reces=length(reces_x);
reces_z=ones(1,num_reces)*10;

%##########################################################################
% construct the structure "rays_geom" for latter use
% we consider the point where source is placed as the OBS. and the other as
% the shots.
% so some reciprocity is used.
num_obs=num_sours;
for iobs=1:num_obs   
    
    cur_obs_x=sours_x(iobs);
    cur_obs_z=sours_z(iobs); 
    
    shots_x=reces_x;   
    shots_z=reces_z;
    t_obs=zeros(size(shots_x));
    num_picks=length(t_obs);     

    % constructe the structure data.
    obs.x=cur_obs_x;                     
    obs.z=cur_obs_z;
    obs.shots_x=shots_x;
    obs.shots_z=shots_z;
    obs.t_obs=t_obs;
    obs.num_picks=num_picks;
    obs.record_num=iobs;
    
    clear shots_x;
    clear shots_z;
    clear t_obs;
    
    rays_geom(iobs)=obs;    
end
save(matfile,'rays_geom');
%###############################end########################################


%QC
%marmousi_true_dg10.mat
load('marmousi_true_dg10.mat');
imagesc(x,z,vel);colormap jet;colorbar;
hold on;

% QC plot
for iobs=1:num_obs 
    obs=rays_geom(iobs);    
    plot(obs.x,obs.z,'o'); 
    plot(obs.shots_x(1:5:end),obs.shots_z(1:5:end),'.');   
end
xlabel('x/m');
ylabel('z/m');






