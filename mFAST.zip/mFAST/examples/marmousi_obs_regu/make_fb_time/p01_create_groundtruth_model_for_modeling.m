%##########################################################################
% 2021 06 18
% 2021 07 11
%##########################################################################
% Create a model for forward modeling to calculate the "Observed data"

load('marmousi_true_dg10.mat');
velsmo=velsmooth(vel,x,z,500);
imagesc(x,z,velsmo);colormap jet;title('true model');
forward_model.dx=dx;
forward_model.dz=dz;
forward_model.x=x;
forward_model.z=z;
forward_model.vel=velsmo;
forward_model.nx=length(x);
forward_model.nz=length(z);
save marmousi_forward_model.mat forward_model;
%##########################################################################





