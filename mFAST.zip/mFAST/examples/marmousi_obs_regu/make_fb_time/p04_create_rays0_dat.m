%##########################################################################
% 2021 07 11
load('synthetic_rays.mat')
fid=fopen('rays0.dat','wb');
%##########################################################################
% QC
%         %  把当前射线的射线路径保存到一个structure中
%         ray.x=ray_x;
%         ray.z=ray_z;
%         ray.xs=xs;
%         ray.zs=zs;
%         ray.xr=cur_xr;
%         ray.zr=cur_zr;
%         ray.t_cal=cur_t_cal;
%         ray.t_obs=cur_t_obs;
%         ray.success=is_success;
nrays=length(rays);
for iray=1:1:nrays
    
    ray=rays(iray);
    if ray.success==1
        cur_shot_x=ray.xr/1000;
        cur_shot_z=ray.zr/1000*-1;
        
        cur_obs_x=ray.xs/1000;
        cur_obs_z=ray.zs/1000*-1;
        
        fb=ray.t_cal;
        
        
        output=[cur_shot_x;cur_shot_z;cur_obs_x;cur_obs_z;fb];
        
        fprintf(fid,'%6.4f %6.4f %6.4f %6.4f %6.4f\n',output);
    end
end

fclose(fid);

%##########################################################################









