% #########################################################################
% for a real data example
% create a ray geometry from the travel time table in the PROFIT code
% format
% 2021 06 30
% 2021 07 01
% 因为矩阵必须是规整的，并不适合实际数据的情形
% tomo2d那种输入方式可行
% 还是用rays 那样的结构体数组比较好吧。
% #########################################################################
%     obs.x=cur_obs_x*1000;           % in m          
%     obs.z=cur_obs_z*1000*-1;        % in m
%     obs.shots_x=shots_x*1000;       % in m 
%     obs.shots_z=shots_z*1000*-1;
%     obs.t_obs=t_obs;                % in second
%     obs.num_picks=cur_obs_picks;
%     obs.record_num=iobs;
% #########################################################################

outmatfile='marmousi_syn2_obs_rays_geom.mat';
% #########################################################################
fb=load('rays0.dat');
npicks=size(fb,1);

%##########################################################################
% 统计OBS个数
num_obs=1;
for ipick=2:npicks
    if fb(ipick,3)~=fb(ipick-1,3)                            % OBS 的x 坐标
        num_obs=num_obs+1;        
    end
end
disp(['There are ',num2str(num_obs),' in total']);

%##########################################################################
% 统计OBS的坐标
obs_x=zeros(num_obs,1);
obs_z=zeros(num_obs,1);
obs_x(1)=fb(1,3);  
obs_z(1)=fb(1,4); 
iobs=1;
for ipick=2:npicks
    if fb(ipick,3)~=fb(ipick-1,3)
        iobs=iobs+1;
        obs_x(iobs)=fb(ipick,3);  % in km
        obs_z(iobs)=fb(ipick,4);  % in km and minus        
    end
end
plot(obs_x,obs_z,'*');
%##########################################################################


%##########################################################################
% 统计每一个OBS的拾取个数
for iobs=1:num_obs
    
    cur_obs_x=obs_x(iobs);
    cur_obs_z=obs_z(iobs);  
    
    % 统计当前OBS的拾取情况，对所有拾取点循环。
    cur_obs_picks=0;
    for ipicks=1:npicks
        if fb(ipicks,3)==cur_obs_x
            cur_obs_picks=cur_obs_picks+1;
            shots_x(cur_obs_picks)=fb(ipicks,1);
            shots_z(cur_obs_picks)=fb(ipicks,2);
            t_obs(cur_obs_picks)=fb(ipicks,5);         % to ms
        end
    end
    
    obs.x=cur_obs_x*1000;                     
    obs.z=cur_obs_z*1000*-1;
    obs.shots_x=shots_x*1000;
    obs.shots_z=shots_z*1000*-1;
    obs.t_obs=t_obs;
    obs.num_picks=cur_obs_picks;
    obs.record_num=iobs;
    
    clear shots_x;
    clear shots_z;
    clear t_obs;
    
    rays_geom(iobs)=obs;    
end 


% QC
figure;
plot(fb(:,1),fb(:,5),'.');
flipy;

figure;
sum=0;
for iobs=1:num_obs
    obs=rays_geom(iobs);
    sum=sum+obs.num_picks;
    plot(obs.shots_x,obs.t_obs,'.');
    title(num2str(iobs));
    pause(1);
    disp(['i am obs ',num2str(iobs),' and i have ', num2str(obs.num_picks),' picks']);
end

disp(sum)
disp(npicks)
    

save(outmatfile,'rays_geom');
%###############################end########################################

