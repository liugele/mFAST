
matfile_for_inversion='new_marmousi_syn2_obs_inversion_';

for iter=1:10  
    
    disp(['I am iteration : ',num2str(iter)]);
    inversion_result=[matfile_for_inversion,'_iter_',num2str(iter),'.mat'];
    load(inversion_result);     
    
    figure;
    subplot(221);
    imagesc(initial_model.vel); colormap jet;colorbar; title(['initial model',num2str(iter)]);    
    subplot(222);
    imagesc(nodes_model.vel,[1500,4000]);  colormap jet;colorbar; title('inverted model');
    subplot(223);
    velsmo=velsmooth(nodes_model.vel,nodes_model.x,nodes_model.z,100);
    imagesc(velsmo,[1500,4000]);  colormap jet;colorbar; title('inverted model after smoothing');   
    subplot(224);    
    load('marmousi_forward_model.mat');
    imagesc(forward_model.vel);  colormap jet;colorbar; title('groundtruth model');
    
    outfig=[matfile_for_inversion,'_iter_',num2str(iter),'.jpg'];
    saveas(gcf,outfig,'jpeg');
    
    
end

% #########################################################################
% 比较最初的初始模型以及最后的反演结果
figure;
inversion_result=[matfile_for_inversion,'_iter_',num2str(1),'.mat'];
load(inversion_result);
subplot(221);
imagesc(initial_model.vel); colormap jet;colorbar; title('initial model');
subplot(222);
imagesc(nodes_model.vel,[1500,4000]);  colormap jet;colorbar; title('inverted model');
inversion_result=[matfile_for_inversion,'_iter_',num2str(10),'.mat'];
load(inversion_result);
subplot(223);
velsmo=velsmooth(nodes_model.vel,nodes_model.x,nodes_model.z,200);
imagesc(velsmo,[1500,4000]);  colormap jet;colorbar; title('inverted model after smoothing');
subplot(224);
load('marmousi_forward_model.mat');
imagesc(forward_model.vel);  colormap jet;colorbar; title('groundtruth model');


