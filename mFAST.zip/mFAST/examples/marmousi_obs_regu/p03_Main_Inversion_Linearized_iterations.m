%##########################################################################
%                          Main Inversion for dongsha data
%##########################################################################
%                            2021 07 04 
%##########################################################################
% inputs
% tobs;
% geometry;
% intial model;
% and inversion_paramter;
% 2021 06 30
%##########################################################################

clear;clc
%##########################################################################
% load geometry and travel time table
load('marmousi_syn2_obs_rays_geom.mat');

% load intial model
load('marmousi_syn2_obs_initial_model_gradient.mat');

%##########################################################################
% load forward modeling paramter

raytracing_par.dstep=10;
raytracing_par.max_steps=1000;

% load inversion parameter
cell_dx=50;
cell_dz=50;
max_iter=10;
tolerance=1;
inversion_par.cell_dx=cell_dx;
inversion_par.cell_dz=cell_dz;
smooth_length=100;

% matfile_name
matfile_for_rays='new_marmousi_syn2_obs_rays_cal_';
matfile_for_inversion='new_marmousi_syn2_obs_inversion_';
flag=0;
%##########################################################################

%##########################################################################
for iter=1:max_iter
    
    disp(['now it is iteration : ',num2str(iter)]);
    
    %##########################################################################
    % 基于初始模型计算射线路径和射线旅行时
    forward_model=initial_model;
    [tcal,success_index,rays]=mFAST_raytracing(forward_model,rays_geom,raytracing_par,flag);
    save([matfile_for_rays,'_iter_',num2str(iter),'.mat'],'rays','tcal','success_index');
    %######################################################################    
    
    %######################################################################
    % 计算矩阵D
    [cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz);
    [D]=Bulid_jacobi_matrix_cells_simple(rays,cells_model,success_index,flag);
    % 建立正则化矩阵
    num_cell_x=cells_model.num_cell_x;
    num_cell_z=cells_model.num_cell_z;
    [regu_lap]=create_laplacian_matrix_reduced(num_cell_x,num_cell_z);
    
    % 
    %  A=[D;regu_lap];  
    % should add a regularization factor mu
     mu=1000;
     A=[D;mu*regu_lap];   
    
    % % 计算delta_t
    % [tcal]=calculate_traveltime_from_raypath(rays,cells_model,success_index,flag);
    
    [t_obs,t_cal,delta_t,t_xxx] = Build_the_delta_t(rays,rays_geom,success_index);
    % 计算右端项的增加行
    S0=cell_twoD2oneD(cells_model.cell_vel,num_cell_x,num_cell_z);
    Aug_t=-1*regu_lap*S0;
    Aug_t=zeros(size(Aug_t));
    DELTA_T=[delta_t;Aug_t];
    
    
    % 计算Delat_S;    D*Delta_S=delta_t;    
    Delta_S = lsqr(A,DELTA_T);
    
    
    %######################################################################
    % 反演后的一维增量变成二维
    twoD=cell_oneD2twoD(Delta_S,cells_model.num_cell_x,cells_model.num_cell_z);
    
    % 得到更新后的Cell速度模型
    cells_model.cell_vel=1./(1./cells_model.cell_vel+twoD);
    
    % 得到更新后的nodes速度模型
    [nodes_model] = cells_model2nodes_model(cells_model,initial_model.dx,initial_model.dz);
    
    
    figure;
    subplot(121);
    imagesc(initial_model.vel); colormap jet;colorbar; title(['initial model iter = ',num2str(iter)]);
    subplot(122);
    imagesc(nodes_model.vel,[1500,8000]);  colormap jet;colorbar; title(['inverted model iter = ',num2str(iter)]);
    
    inversion_result=[matfile_for_inversion,'_iter_',num2str(iter),'.mat'];
    save(inversion_result,'t_obs','t_cal','delta_t','t_xxx','Delta_S','initial_model','nodes_model');
    
    % #####################################################################
    % 更新得到的速度作为下一次迭代的初始模型
    vel0=nodes_model.vel;
    x=nodes_model.x;
    z=nodes_model.z;    
    vel0=velsmooth(vel0,x,z,smooth_length);
    vel0(vel0<1500)=1500;
    vel0(vel0>5000)=5000;
    initial_model.vel=vel0;
    % #####################################################################
end


