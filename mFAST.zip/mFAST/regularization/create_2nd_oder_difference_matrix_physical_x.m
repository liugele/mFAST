function [Regu_2nd_oder_x]=create_2nd_oder_difference_matrix_physical_x(NX_cells,NZ_cells)
% 2021 07 16
% The function "create_1st_oder_difference_matrix_simple"
% constructs a difference matrix with the assumption that all the cells
% are equal
% But physically, Cells are not equal. some of the cells are in the corner
% some are at the boundaries.
% construt the first order difference matrix 
% NX_cells : number of cells in one row;
% NZ_cells : number of cells in one column;
%  ************************************************************************
%  *  *  *  *  *  *  *  *  *
%  *     *     *     *     *     1  2  3  4
%  *  *  *  *  *  *  *  *  *
%  *     *     *     *     *     5  6  7  8
%  *  *  *  *  *  *  *  *  *
%  *     *     *     *     *     9  10  11  12
%  *  *  *  *  *  *  *  *  *

% create_2nd_oder_difference_matrix_physical(3,3)
% 
% ans =
% 
%      0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0
%      0     0     0     1    -2     1     0     0     0
%      0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0
%      0     0     0     0     0     0     0     0     0
%
% *************************************************************************
% The number of cells that can be constrainted by 1 st oder difference 
% num_row=(NX_cells-1)*NZ_cells; 
% The number of cells whose slownesses will be updated
num_column=NX_cells*NZ_cells;
Regu_2nd_oder_x=zeros(num_column,num_column);

%  ************************************************************************
% constrain the cells that are not associated with the four boundaries
% interior cells;
% 2:NX_Cells-1
% 2:NZ_cells-1

for iz=2:NZ_cells-1
    for ix=2:NX_cells-1  
        
        % transform the 2D index(iz,ix) to the 1D format        
        index_1d=(iz-1)*NX_cells+ix; 
        
        Regu_2nd_oder_x(index_1d,index_1d)=-2;
        Regu_2nd_oder_x(index_1d,index_1d-1)=1;
        Regu_2nd_oder_x(index_1d,index_1d+1)=1;       

    end
end
end
        
        

        
        
        
        












