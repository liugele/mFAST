function [f,g]=mFAST_misfit_and_g_nodes_vel(forward_model,ray_geom,raytracing_par,inversion_par,tobs)
%##########################################################################
% 2021 06 10
% calculate the misfit value and the gradient at the current model
% based on the nodes-based forward_model
%##########################################################################
% parameter
cell_dx=inversion_par.cell_dx;
cell_dz=inversion_par.cell_dz;

%##########################################################################
% raytracing at the current model
[tcal,success_index,rays]=mFAST_raytracing(forward_model,ray_geom,raytracing_par,flag);
% create the jacobi_matrix
disp('building the Jacobi matrix ......');
% Create Cell model
[cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz);
% build raypath matrix  according to the Cell model
[jacobi_matrix]=Bulid_jacobi_matrix_cells(rays,cells_model,success_index,flag);


% select the effective rays
nrays=length(tcal);
neffective_rays=sum(success_index);
delta_t=zeros(neffective_rays,1);
i_effective_rays=0;
for iray=1:nrays
    if success_index(iray)==1
       i_effective_rays=i_effective_rays+1;
       delta_t(i_effective_rays)=tobs(iray)-tcal(iray);
    end
end

% output the misfit function value  and the gradient;
f=norm(delta_t,2);
g=transpose(jacobi_matrix)*delta_t;

end

