function [f,g]=mFAST_misfit_and_g(slowness_vector,ray_geom,raytracing_par,inversion_par,tobs)
%##########################################################################
% 2021 06 10
% calculate the misfit value and the gradient at the current model

%##########################################################################
% parameter
cell_dx=inversion_par.cell_dx;
cell_dz=inversion_par.cell_dz;

num_cell_x=inversion_par.num_cell_x;
num_cell_z=inversion_par.num_cell_z;

% create cells_model based on the cell-based 1d slowness vector;
slowness_2d=cell_oneD2twoD(slowness_vector,num_cell_x,num_cell_z);
cells_model.num_cell_x=num_cell_x;
cells_model.num_cell_z=num_cell_z;
cells_model.cell_dx=cell_dx;
cells_model.cell_dz=cell_dz;
cells_model.x=0:cell_dx:num_cell_x*cell_dx;
cells_model.z=0:cell_dz:num_cell_z*cell_dz;
cells_model.cell_vel=1./slowness_2d;


% create nodes_model from the cells_model for forward_modeling;
dx=raytracing_par.forward_dx;
dz=raytracing_par.forward_dz;
[forward_model] = cells_model2nodes_model(cells_model,dx,dz);
%##########################################################################
% raytracing at the current model
[tcal,success_index,rays]=mFAST_raytracing(forward_model,ray_geom,raytracing_par,flag);
% create the jacobi_matrix
disp('building the Jacobi matrix ......');
% Create Cell model
[cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz);
% build raypath matrix  according to the Cell model
[jacobi_matrix]=Bulid_jacobi_matrix_cells(rays,cells_model,success_index,flag);


% select the effective rays
nrays=length(tcal);
neffective_rays=sum(success_index);
delta_t=zeros(neffective_rays,1);
i_effective_rays=0;
for iray=1:nrays
    if success_index(iray)==1
       i_effective_rays=i_effective_rays+1;
       delta_t(i_effective_rays)=tobs(iray)-tcal(iray);
    end
end

% output the misfit function value  and the gradient;
f=norm(delta_t,2);
g=transpose(jacobi_matrix)*delta_t;

end

