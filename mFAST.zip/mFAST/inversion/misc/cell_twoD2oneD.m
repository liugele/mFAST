function oneD=cell_twoD2oneD(twoD,num_cell_x,num_cell_z)

oneD=zeros(num_cell_x*num_cell_z,1);
for iz_cell_z=1:num_cell_z
    for ix_cell_x=1:num_cell_x
        cell_1d=(iz_cell_z-1)*num_cell_x+ix_cell_x;
        oneD(cell_1d)=twoD(iz_cell_z,ix_cell_x);
    end
end





