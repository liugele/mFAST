function [tcal,success_index,rays]=mFAST_raytracing(forward_model,rays_geom,raytracing_par,flag)
%##########################################################################
% 2021 05 31
% using the following formula to trace the raypath
% xnext=xcur+alpah*gradient_x;
% znext=zcur+alpah*gradient_z;
%##########################################################################
% 2021 06 10
% simplify the code
% change the style of the ray_geom%
%     obs.x=cur_obs_x*1000;
%     obs.z=cur_obs_z*1000*-1;
%     obs.shots_x=shots_x*1000;
%     obs.shots_z=shots_z*1000*-1;
%     obs.t_obs=t_obs*1000;
%     obs.num_picks=cur_obs_picks;
%     obs.record_num=iobs;
%##########################################################################


%##########################################################################
% model paramters
x=forward_model.x;
z=forward_model.z;
dx=forward_model.dx;
dz=forward_model.dz;
% check
if dx~=dz
    error('dx~=dz');
end
%##########################################################################


%##########################################################################
% calculate how many rays are evolved
num_obs=length(rays_geom);
nrays=0;
for i=1:num_obs
    cur_obs=rays_geom(i);
    npicks=cur_obs.num_picks;
    nrays=nrays+npicks;
end
disp(['There are  ',num2str(nrays),'  source-receiver pairs in the real data set']);
%##########################################################################


%##########################################################################
x0=x(1);x1=x(end);
z0=z(1);z1=z(end);
tcal=zeros(nrays,1);
success_index=zeros(nrays,1);
%##########################################################################


%##########################################################################
% Slowness model
vel=forward_model.vel;
S=1./vel;
%##########################################################################

%##########################################################################
% raytracing paramters
ds=raytracing_par.dstep;
max_steps=raytracing_par.max_steps;
%##########################################################################


%##########################################################################
%              Raytracing for all shot and receiver pairs
%##########################################################################
iray=0;
for iobs=1:num_obs
    
    cur_obs=rays_geom(iobs);
    
    if flag==1
    disp(['source ',num2str(iobs) ,' of ',num2str(num_obs)]);
    end
    
    % #####################################################################
    % obtain the physical coordinates for current OBS
    xs=cur_obs.x;             %physical coordinates
    zs=cur_obs.z;                 
    izs=near(z,zs);           %grid numbers
    ixs=near(x,xs);
    
    %######################################################################
    % Compute travel time field for current OBS
    
    sp=[izs,ixs];
    [TT]=Mray(S,sp,dx);
    
    
    %######################################################################
    % minus gradient
    [dtdx,dtdz]=gradient(TT,dx,dz);
    gradient_x1=-dtdx;
    gradient_z1=-dtdz;
    
    %######################################################################
    
    
    %######################################################################
    %                 raytracing for each shot points
    %######################################################################
    reces_x=cur_obs.shots_x;
    reces_z=cur_obs.shots_z;
    t_obs=cur_obs.t_obs;
    
    num_reces=length(reces_x);
    if num_reces~=cur_obs.num_picks
        error('the receiver number is inconsistent with the num_picks');
    end
    disp(['There are ',num2str(num_reces),' receivers for current OBS ']);
    
    for irec=1:num_reces
                
        iray=iray+1;
        
        if flag==1
        disp(['ray ',num2str(iray),' of ', num2str(nrays)]);end
        
        % first, obtain the physical coordinate of receiver point (here it is shot point since interchange has been conducted)
        cur_zr=reces_z(irec);
        cur_xr=reces_x(irec);  
        
        % observed time for current OBS-shot pairs
        cur_t_obs=t_obs(irec);
               
        
        % receiver point as the starting point of raytracing
        ray_x_cur=cur_xr;
        ray_z_cur=cur_zr;
        
        % make a record of the points within the ray
        ray_num_ponit=1;
        
        % points on the raypath are stored into a array 
        ray_x(ray_num_ponit)=ray_x_cur;   %physical coordinate
        ray_z(ray_num_ponit)=ray_z_cur;   %physical coordinate
        
        
        
        %##################################################################
        %        raytracing for current OBS-shot pairs
        %##################################################################
        % while(~is_source_cell( xs,zs,ray_x_cur,ray_z_cur,dx,dz)&&~is_exceed_boundary(ray_x_cur,ray_z_cur,x0,x1,z0,z1))
        % raytracing stops when ray enters into the cell where source is located or ray goes outside the model
        istep=0;
        while(~is_source_cell( xs,zs,ray_x_cur,ray_z_cur,dx,dz)&&~is_exceed_boundary(ray_x_cur,ray_z_cur,x0,x1,z0,z1))
            
            % grid number of current
            ix_cur=min(near(x,ray_x_cur));  % near 
            iz_cur=min(near(z,ray_z_cur));
            
%             if iz_cur>forward_model.nz||ix_cur>forward_model.nx
%                 break;
%             end
            
            % minus gradient at current location
            gx_cur=gradient_x1(iz_cur,ix_cur);
            gz_cur=gradient_z1(iz_cur,ix_cur);
            
            
            %##############################################################
            % compute the next point based on the minus gradient and
            % raytracing step
            if gx_cur^2+gz_cur^2==0
                error('gradient is zero');
            end            
            
            if gx_cur==0
                x_next=ray_x_cur;
                z_next=ray_z_cur+ds*gz_cur/sqrt(gx_cur^2+gz_cur^2); 
            end            
            
            if gz_cur==0
                x_next=ray_x_cur+ds*gx_cur/sqrt(gx_cur^2+gz_cur^2);
                z_next=ray_z_cur;
            end
            
            if gx_cur^2+gz_cur^2~=0                
                x_next=ray_x_cur+ds*gx_cur/sqrt(gx_cur^2+gz_cur^2);
                z_next=ray_z_cur+ds*gz_cur/sqrt(gx_cur^2+gz_cur^2);                
            end
            %##############################################################
            
            
            
            % update raypath point
            ray_x_cur=x_next;
            ray_z_cur=z_next;
            
            % 
            ray_num_ponit=ray_num_ponit+1;
            ray_x(ray_num_ponit)=ray_x_cur;           
            ray_z(ray_num_ponit)=ray_z_cur;           
            
            istep=istep+1;
            
            if istep>max_steps
                disp(['ray ',num2str(iray),' of ', num2str(nrays),'raytracing failure']);
                break;                
            end
            
        end
        
        if flag==1
        disp(['ray ',num2str(iray),' of ', num2str(nrays),...
            ' @ source ',num2str(iobs) ,' of ',num2str(num_obs),' finished']);
        end
        % raytracing for current OBS-shot pairs is finished 
        %##################################################################
        
        
        %##################################################################
        % determine whether current raypath is effective or not

        is_success=is_source_cell( xs,zs,ray_x_cur,ray_z_cur,dx,dz);
        success_index(iray)=is_success;
        
        %############
        % compute the travel time for current raypath
        i_cur_xr=min(near(x,cur_xr));
        i_cur_zr=min(near(z,cur_zr));
        cur_t_cal=TT(i_cur_zr,i_cur_xr);
        tcal(iray)=cur_t_cal;
        
        %############
        %       
        if ~(xs==ray_x_cur&&zs==ray_z_cur)
            ray_x(ray_num_ponit+1)=xs;
            ray_z(ray_num_ponit+1)=zs;
        end 
        
        
        %  all the information associated with current ray is stored into a
        %  structure.
        ray.x=ray_x;
        ray.z=ray_z;
        ray.xs=xs;
        ray.zs=zs;
        ray.xr=cur_xr;
        ray.zr=cur_zr;
        ray.t_cal=cur_t_cal;
        ray.t_obs=cur_t_obs;
        ray.success=is_success;
        
        rays(iray)=ray;
        
        %###################################################################
        clear ray_x;
        clear ray_z;
        %###################################################################
        
    end
    % raytracing for current OBS is finished
    disp(['source ',num2str(iobs) ,' of ',num2str(num_obs),' finished']);
    %######################################################################
end
% raytracing for all OBS is finished
%##########################################################################
end


