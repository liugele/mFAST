

function is_in_source_cell = is_source_cell( xs,zs,xr,zr,dx,dz)

        if abs(xr-xs)<=dx&&abs(zr-zs)<=dz
            is_in_source_cell=1;
        else
            is_in_source_cell=0;
        end
       
            



end

