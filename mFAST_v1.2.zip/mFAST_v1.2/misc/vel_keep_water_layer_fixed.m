function vel_water_fixed = vel_keep_water_layer_fixed(vel,x,z,seafloor,v_constant)

% This function is used to keep the water colum velocity fixed
dz=z(2)-z(1);
[nz,nx]=size(vel);
seafloor.x(end)=max(x);
vel_water_fixed=vel;

for ix=1:nx
    xx=x(ix);
    seafloor_zz=interp1(seafloor.x,seafloor.z,xx);
    iseafloor_zz=fix(seafloor_zz/dz)+1;
    vel_water_fixed(1:iseafloor_zz,ix)=v_constant;
end
end