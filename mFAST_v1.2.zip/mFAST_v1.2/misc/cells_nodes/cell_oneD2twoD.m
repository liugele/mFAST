function twoD=cell_oneD2twoD(oneD,num_cell_x,num_cell_z)

twoD=zeros(num_cell_z,num_cell_x);
for iz=1:num_cell_z
    fist=(iz-1)*num_cell_x+1;
    last=iz*num_cell_x;
    twoD(iz,:)=oneD(fist:last);
end

end

