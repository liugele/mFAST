function [cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz)
%##########################################################################
% 2021 06 07
% Create a Cell_model used for update from the forward model
% Because we only update velocity at Cells
% 2021 07 01
%##########################################################################

% read the parameter of nodes_model that is also forward_model

x=forward_model.x;
z=forward_model.z;
vel=forward_model.vel;


% 
% Create Cell model
X=x(1):cell_dx:x(end);
Z=z(1):cell_dz:z(end);
NX=length(X);
NZ=length(Z);

% number of cells in x and z directions 
num_cell_x=NX-1;
num_cell_z=NZ-1;
cell_vel=zeros(num_cell_z,num_cell_x);

for icellx=1:num_cell_x
    for icellz=1:num_cell_z
        % find the four corner nodes.
        x0=X(icellx);  x1=X(icellx+1);
        z0=Z(icellz);  z1=Z(icellz+1);
        
        ix0=find(x==x0);
        ix1=find(x==x1);
        
        iz0=find(z==z0);
        iz1=find(z==z1);
        
        
        v00=vel(iz0,ix0);
        v01=vel(iz0,ix1);
        v10=vel(iz1,ix0);
        v11=vel(iz1,ix1);
        
        
        cell_vel(icellz,icellx)=1/4*(v00+v01+v10+v11);
        
    end
end          
        



% figure; imagesc(Cell_vel);colormap jet;title('Cell_vel_model');

cells_model.num_cell_x=num_cell_x;
cells_model.num_cell_z=num_cell_z;
cells_model.cell_dx=cell_dx;
cells_model.cell_dz=cell_dz;
cells_model.cell_vel=cell_vel;
cells_model.x=X;
cells_model.z=Z;

end

