
function [nodes_model] = cells_model2nodes_model(cells_model,dx,dz)
%##########################################################################
%  2021 06 07
%  interplate the velocities on the cells to the velocities on the nodes.
%  
%##########################################################################
% cells_model.num_cell_x=num_cell_x;
% cells_model.num_cell_z=num_cell_z;
% cells_model.cell_dx=cell_dx;
% cells_model.cell_dz=cell_dz;
% cells_model.Cell_vel=Cell_vel;
% cells_model.x=x1;
% cells_model.z=z1;

num_cell_x=cells_model.num_cell_x;
num_cell_z=cells_model.num_cell_z;
cell_dx=cells_model.cell_dx;
cell_dz=cells_model.cell_dz;
cell_vel=cells_model.cell_vel;
cell_x=cells_model.x;
cell_z=cells_model.z;

%##########################################################################
% create a node-based model from the cell-based model
x=cell_x(1):dx:cell_x(end);
z=cell_z(1):dz:cell_z(end);
nx=length(x);
nz=length(z);

vel=zeros(nz,nx);
for ix=1:nx
    for iz=1:nz
        xx=x(ix);
        zz=z(iz);        
        ix_cell=min(fix(xx/cell_dx)+1,num_cell_x);
        iz_cell=min(fix(zz/cell_dz)+1,num_cell_z);        
        vel(iz,ix)=cell_vel(iz_cell,ix_cell);
    end
end



nodes_model.nx=nx;
nodes_model.nz=nz;
nodes_model.x=x;
nodes_model.z=z;
nodes_model.dx=dx;
nodes_model.dz=dz;
nodes_model.vel=vel;


end

