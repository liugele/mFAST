%##########################################################################
% load observed data
% D:\matlab_lb\mFAST_bp\examples\Marmousi
load('D:\matlab_lb\mFAST_bp_v1\examples\Marmousi\Marmousi_synthetic_tobs.mat');
% load initial model
load('D:\matlab_lb\mFAST_bp_v1\Model\marmousi_initial_model.mat');
% load geometry
load('ray_geom.mat');
%##########################################################################


niter=10;
forward_model=initial_model;
vel=initial_model.vel;

cell_dx=100;
cell_dz=100;
flag=0; % do not 


raytracing_par.dstep=10;           % 10 m
raytracing_par.max_steps=1000;
%##########################################################################
[cells_model] = nodes_model2cells_model(forward_model,100,100);
[tcal,success_index,rays]=mFAST_raytracing(forward_model,ray_geom,raytracing_par,flag);
[jacobi_matrix]=Bulid_jacobi_matrix_cells(rays,cells_model,success_index,1);

imagesc(jacobi_matrix);

num_cell_x=cells_model.num_cell_x;
num_cell_z=cells_model.num_cell_z;



iray=input('input the iray for display and 0 for end:');
while iray~=0
    ray=jacobi_matrix(iray,:);
    kernel1=cell_oneD2twoD(ray,num_cell_x,num_cell_z);
    imagesc(kernel1);
    iray=input('input the iray for display and 0 for end:');
end

density=zeros(num_cell_z,num_cell_x);
for iray=1:900
    ray=jacobi_matrix(iray,:);
    kernel1=cell_oneD2twoD(ray,num_cell_x,num_cell_z);
    density=density+kernel1;
end

subplot(311)
imagesc(density,[-1000,1000]);title('density limit 1000');colormap jet;
subplot(312)
imagesc(density);title('density full');colormap jet;
subplot(313)
for iray=1:10:900
    ray=rays(iray);
    rayx=ray.x;
    rayz=ray.z;
    plot(rayx,rayz,'k.');
    hold on;
end
flipy;

figure;
for iray=900
    ray=jacobi_matrix(iray,:);
    kernel1=cell_oneD2twoD(ray,num_cell_x,num_cell_z);
    subplot(121);
    imagesc(kernel1,[-100,100]);
    title(['ray : ',num2str(iray),'max :',num2str(max(max(kernel1)))]);
    colorbar;
    subplot(122);
    imagesc(forward_model.x,forward_model.z,forward_model.vel);colormap jet;
    hold on;
    ray=rays(iray);
    rayx=ray.x;
    rayz=ray.z;
    plot(rayx,rayz,'k.'); title(['ray : ',num2str(iray)]);
    %     pause(0.01);
end

