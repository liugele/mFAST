%##########################################################################
% 2014 09 10
% Set the shots and receicers position
% 2021 05 31
% 2022 04 18
%##########################################################################

%##########################################################################
% step1 load the true model
%##########################################################################
load("marmousi_true_dg25_with_seafloor.mat");
load("seafloor.mat");

%##########################################################################
% step2 synthetic first arrival time for OBSs on the seafloor
OBSs_x=3000:1000:17000;
seafloor_topo=seafloor;
xshots=x;
zshots=ones(size(x))*dz;
fb_txtfile_name='fb_time.dat';

% create_rays_geom;
[rays_geom]=fun_make_synthetic_obs_first_break(vel,x,z,OBSs_x,xshots,zshots,seafloor_topo,fb_txtfile_name);

%##########################################################################
save rays_geom.mat rays_geom;
%##########################################################################
