%##########################################################################
% ģ��
load('marmousi_initial_model.mat');
load('marmousi_forward_model.mat');
% �۲�ϵͳ����
load('marmousi_syn2_obs_rays_geom.mat');
% ����׷�ٲ���
flag=1;
raytracing_par.dstep=10;            % 10 m
raytracing_par.max_steps=10000;      % maximum steps
%##########################################################################
%##########################################################################
[tcal,success_index,rays]=mFAST_raytracing(initial_model,rays_geom,raytracing_par,flag);
tobs=tcal;
%##########################################################################
outmat='Marmousi_initial_model_tobs.mat';
save(outmat,'initial_model','tobs','rays','success_index');
%##########################################################################

%
% plot rays;
figure;
imagesc(initial_model.x,initial_model.z,initial_model.vel);colormap jet;
colorbar;
hold on;
nrays=size(rays,2);
for i=1:5:400
    cur_ray=rays(i);
    x=cur_ray.x;
    z=cur_ray.z;
    plot(x,z,'k.');
end


%##########################################################################
% set some paramters for fd modeling
%##########################################################################
% set the parameters
boundary=1;
laplacian=2;   % disp(' Type 1 for 2nd order Laplacian, 2 for 4th order Laplacian');
tmax=3;
% set the source position in the form of coordinates
cur_obs=rays_geom(1);
sx=cur_obs.x;
sz=cur_obs.z;
ns=length(sx);
% set the receiver position in the form of coordinates
gx=cur_obs.shots_x;
gz=cur_obs.shots_z;
ng=length(gx);
xrec=gx;
zrec=gz;

% time steps and wavelets
nt=6001;
dtstep=0.0004;   % time step size for finite difference modedling
dtout=0.001;     % % temporal sample rate for the output
fdom=10;
[wavelet,tw]=ricker(dtstep,fdom,0.128);
plot(tw,wavelet);
pause(1);
%##########################################################################
% the source position and the initial wavefields
xshot=sx;
zshot=fix(sz/dx)*dx;
%##########################################################################
vel=initial_model.vel;
x=initial_model.x;
dx=x(2)-x(1);
seismat=['marmousi_obs1_fd.mat'];


[seisw,t]=afd_shotrec_alt(dx,dtstep,dtout,tmax, ...
    vel,xshot,zshot,xrec,zrec,wavelet,tw,laplacian,boundary);

save(seismat,'seisw','t','xrec','zrec','xshot','zshot');
%##########################################################################

figure;
imagesc(xrec,t*1000,seisw);colormap jet; colorbar;
hold on;
% overlay the time
nrays=size(rays,2);
cur_ray=rays(1);
x1=cur_ray.xr;
z1=cur_ray.zr;
xs1=cur_ray.xs;
t1=cur_ray.t_cal;
plot(x1,t1*1000,'k.');
for i=2:nrays
    cur_ray=rays(i);
    x=cur_ray.xr;
    z=cur_ray.zr;
    xs=cur_ray.xs;
    tcal=cur_ray.t_cal;
    if xs==xs1
        plot(x,tcal*1000,'k.');
    end
end

% end the comparison of travel time and synthetic shot
%##########################################################################




