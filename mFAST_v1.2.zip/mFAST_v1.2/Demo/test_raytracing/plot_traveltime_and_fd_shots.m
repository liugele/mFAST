%##########################################################################
seismat='marmousi_obs1_fd.mat';
load(seismat);

outmat='Marmousi_initial_model_tobs.mat';
load(outmat);

figure;
imagesc(xrec,t*1000,seisw,[-0.0001,0.0001]);xlabel('receiver x/m');
ylabel('time/ms');
hold on;
% overlay the time
nrays=size(rays,2);
cur_ray=rays(1);
x1=cur_ray.xr;
z1=cur_ray.zr;
xs1=cur_ray.xs;
t1=cur_ray.t_cal;
plot(x1,t1*1000,'r.');
for i=2:nrays
    cur_ray=rays(i);
    x=cur_ray.xr;
    z=cur_ray.zr;
    xs=cur_ray.xs;
    t22=cur_ray.t_cal;
    if xs==xs1
        plot(x,t22*1000,'r.');
    end
end
% end the comparison of travel time and synthetic shot
%##########################################################################




