
% load a nodes-based model
load('marmousi_initial_model.mat');
%##########################################################################
forward_model=initial_model;
[cells_model] = nodes_model2cells_model(forward_model,100,100);

%##########################################################################
subplot(221);
imagesc(forward_model.x,forward_model.z,forward_model.vel);title('original nodes-based model');
colormap jet;
subplot(222);
imagesc(cells_model.x,cells_model.z,cells_model.cell_vel);title('Cells-based model');
colormap jet;

[nodes_model] = cells_model2nodes_model(cells_model,10,10);
subplot(223);
imagesc(cells_model.x,cells_model.z,cells_model.cell_vel);title('Cells-based model');
colormap jet;
subplot(224);
imagesc(nodes_model.x,nodes_model.z,nodes_model.vel); title('nodes-based model from cell mode');
colormap jet;


