
function [Regu_1st_oder]=create_1st_oder_difference_matrix_simple(NX_cells,NZ_cells)
% 2021 07 16
% construt the first order difference matrix 
% constrain the cells from the first column to the last second column
% NX_cells : number of cells in one row;
% NZ_cells : number of cells in one column;
%  ************************************************************************
%  *  *  *  *  *  *  *  *  *
%  *     *     *     *     *     1  2  3  4
%  *  *  *  *  *  *  *  *  *
%  *     *     *     *     *     5  6  7  8
%  *  *  *  *  *  *  *  *  *
%  *     *     *     *     *     9  10  11  12
%  *  *  *  *  *  *  *  *  *

%  ************************************************************************
% % The number of cells that can be constrainted by 1 st oder difference 
% num_row=(NX_cells-1)*NZ_cells; 
% The number of cells whose slownesses will be updated
num_column=NX_cells*NZ_cells;
num_row=num_column-1;

Regu_1st_oder=zeros(num_row,num_column);

for irow=1:num_row
    Regu_1st_oder(irow,irow)=-1;
    Regu_1st_oder(irow,irow+1)=1;
end







