
%##########################################################################
% 2022 05 10
% This script is used to create a figure for paper
%##########################################################################
% load everything for tomo
% save('Everything_for_tomo_input.mat','rays_geom','initial_model','inversion_par','forward_par');
load("Everything_for_tomo_input.mat");

%##########################################################################
%step 3 tomography
%##################
% forward parmaters
forward_par.dstep=50;
forward_par.max_steps=20000;
forward_par.flag=0;
% inversion paramters
inversion_par.cell_dx=500;
inversion_par.cell_dz=50;
inversion_par.max_iter=5;
inversion_par.tolerance=1;
inversion_par.vmin=1500;
inversion_par.vmax=8000;
inversion_par.mu=1000;
inversion_par.smooth_length=500; % m
%########################

% % example 1
% matfile_name_par.for_rays='example1_rays';
% matfile_name_par.for_inversion_model='example1_inverison_model';
% mFAST_tomo_no_regu_no_mask(rays_geom,initial_model,seafloor,forward_par,inversion_par,matfile_name_par);


% example 2
matfile_name_par.for_rays='example2_rays';
matfile_name_par.for_inversion_model='example2_inverison_model';
mFAST_tomo_no_regu_no_mask(rays_geom,initial_model,seafloor,forward_par,inversion_par,matfile_name_par);

% % example 2
% 
% % inversion_par.vmin=vmin;
% % inversion_par.vmax=vmax;
% inversion_par.mu=1000;
% inversion_par.flag=1;
% matfile_name_par.for_rays='example2_rays';
% matfile_name_par.for_inversion_model='example2_inverison_model';
% mFAST_tomo(rays_geom,initial_model,seafloor,forward_par,inversion_par,matfile_name_par);
% 
% 
% 
% % example 3
% inversion_par.smooth_length=500;
% % inversion_par.vmin=vmin;
% % inversion_par.vmax=vmax;
% inversion_par.mu=1000;
% inversion_par.flag=0;
% seafloor=initial_model.seafloor;
% matfile_name_par.for_rays='example3_rays';
% matfile_name_par.for_inversion_model='example3_inverison_model';
% mFAST_tomo_regu_no_mask(rays_geom,initial_model,seafloor,forward_par,inversion_par,matfile_name_par);
