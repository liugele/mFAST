    
load("example2_inverison_model_iter_5.mat");
figure ;
for i=1:4
 smooth_length=i*100;
 x=inverted_model.x;
 z=inverted_model.z;   
 vel=inverted_model.vel;
 vel0=velsmooth(vel,x,z,smooth_length);
 subplot(2,2,i);
 title(['smothing length = ',num2str(smooth_length)]);
 imagesc(x,z,vel0);colormap jet; 
end