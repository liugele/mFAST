
%##########################################################################
% 2022 05 10
% This script is used to create a figure for paper
%##########################################################################
% step1 load the true model
load("marmousi_modified_model_dx25_scale2_sm500.mat");
vmin=min(min(vel));
vmax=max(max(vel));
%##########################################################################

%##########################################################################
% step2 synthetic first arrival time for OBSs on the seafloor
%#######################
% set the geometry
% OBSs_x=1000:2000:21000;
OBSs_x=200:1000:21200;
seafloor_topo=seafloor;
xshots=x;
zshots=ones(size(x))*dz;
fb_txtfile_name='fb_time.dat';

% calculate the synthetic traveltime 
[rays_geom]=fun_make_synthetic_obs_first_break(vel,x,z,OBSs_x,xshots,zshots,seafloor_topo,fb_txtfile_name);

% plot the geometry
figure; 
imagesc(x,z,vel);hold on;
for obs_x=OBSs_x
    obs_z=interp1(seafloor.x,seafloor.z,obs_x);
    plot(obs_x,obs_z,'ro');    
end

%##########################################################################
% 3 prepare the forward and inversion paramters
%##################
% forward parmaters
forward_par.dstep=50;
forward_par.max_steps=20000;
forward_par.flag=0;
% inversion paramters
inversion_par.cell_dx=500;
inversion_par.cell_dz=50;
inversion_par.max_iter=5;
inversion_par.tolerance=1;
inversion_par.vmin=vmin;
inversion_par.vmax=vmax;
inversion_par.mu=1000;
inversion_par.smooth_length=500; % m
inversion_par.flag=0;
%########################
% create an initial_model
xmax=max(x);
zmax=9000;
[initial_model]=fun_create_initial_model_gradient_with_seafloor(dx,dz,xmax,zmax,vmin,vmax,seafloor);

save('Everything_for_tomo_input.mat','rays_geom','initial_model','inversion_par','forward_par');


