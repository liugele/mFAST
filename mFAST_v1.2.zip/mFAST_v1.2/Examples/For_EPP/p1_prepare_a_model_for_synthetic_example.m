%##########################################################################
%                         2022 02 27
%##########################################################################
clear;clc;
% load the original velocity model.
% original model nx=941 nz=301 dx=10 dz=10;
load('marmousi_dz10.mat');


% change1 : change the grid interval
dx=25; dz=25;
xmax=22*1000;
zmax=7500; 
x=0:dx:xmax; z=0:dz:zmax;
nx=length(x); nz=length(z);

% change2 : increase the velocity value to make the refraction more visible
vel(1:40,:)=vel(1:40,:)*2;
vel(41:80,:)=vel(41:80,:)*2;
vel(81:200,:)=vel(81:200,:)*2;
vel(201:nz,:)=vel(201:nz,:)*2;
vel(vel>8000)=8000;

vel2=vel;
vel=vel2(:,1:nx);

imagesc(x,z,vel);
% create a seafloor
flag=1;
seafloor=prepare_inputs_seafloor_from_default_txt('seafloor.txt',x,1);
% seafloor.z=seafloor.z;

% create a water layer
[vel_with_water]=fun_create_a_model_with_water_layer(vel,x,z,seafloor);
vel=vel_with_water;
% save
save('marmousi_modified_model_dx25_scale2.mat','x','z','vel','dx','dz','nx','nz','seafloor');
% plot 
figure;
imagesc(x/1000,z/1000,vel);colormap jet;
imagesc(x/1000,z/1000,vel);hold on;
plot(seafloor.x/1000,seafloor.z);
xlabel('x/km');
ylabel('depth/km');


% smoothing 
vel2=velsmooth(vel,x,z,500);
figure;
imagesc(x/1000,z/1000,vel2);colormap jet;
imagesc(x/1000,z/1000,vel2);hold on;
plot(seafloor.x/1000,seafloor.z);
xlabel('x/km');
ylabel('depth/km');
vel=vel2;

save('marmousi_modified_model_dx25_scale2_sm500.mat','x','z','vel','dx','dz','nx','nz','seafloor');


% smoothing 
vel3=velsmooth(vel,x,z,2000);
figure;
imagesc(x/1000,z/1000,vel3);colormap jet;
imagesc(x/1000,z/1000,vel3);hold on;
plot(seafloor.x/1000,seafloor.z);
xlabel('x/km');
ylabel('depth/km');
vel=vel3;

save('marmousi_modified_model_dx25_scale2_sm2000.mat','x','z','vel','dx','dz','nx','nz','seafloor');


