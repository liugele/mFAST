%##########################################################################
inversion_resultfile=uigetfile('*.mat');
load(inversion_resultfile);

plot(t_xxx,t_cal,'k.'); hold on;
plot(t_xxx,t_obs,'r.');

title(inversion_resultfile);