
cd(pwd);

matfilename=uigetfile;
matfile_for_inversion_prefix=matfilename(1:end-5);

matfiles=ls([matfile_for_inversion_prefix,'*.mat']);

num=size(matfiles,1);

rms_time=zeros(num,1);
for iter=1:num      
    inversion_result=[matfile_for_inversion_prefix,num2str(iter)];
    load(inversion_result);    
    plot(t_xxx,t_cal-t_obs,'.');   
    rms_time(iter)=rms(t_cal-t_obs);
    title(['Iteration : ',num2str(iter)]);      
    pause;   
end

figure;
plot(1:num,rms_time,'.');
xlabel('Iterations');
ylabel('RMS');
hold on;
plot(1:num,rms_time,'r');
xlabel('Iterations');
ylabel('RMS');






