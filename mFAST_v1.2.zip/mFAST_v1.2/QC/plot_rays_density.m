%##########################################################################
% 2022 04 19
clear;
close all;
cd(pwd);


model_file=uigetfile('select a model file please :');
load(model_file);

rays_file=uigetfile('select a ray file please :');
load(rays_file);
%##########################################################################

forward_model=initial_model;
cell_dx=1000;
cell_dz=500;
flag=0; 
%##########################################################################
[cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz);
[jacobi_matrix]=Bulid_jacobi_matrix_cells(rays,cells_model,success_index,flag);
imagesc(jacobi_matrix);


num_cell_x=cells_model.num_cell_x;
num_cell_z=cells_model.num_cell_z;
% plot the kernel1 from one single ray
% iray=input('input the iray for display and 0 for end:');
% while iray~=0
%     ray=jacobi_matrix(iray,:);
%     kernel1=cell_oneD2twoD(ray,num_cell_x,num_cell_z);
%     imagesc(kernel1);
%     iray=input('input the iray for display and 0 for end:');
% end

density=zeros(num_cell_z,num_cell_x);
num_rays=size(jacobi_matrix,1);

for iray=1:num_rays
    ray=jacobi_matrix(iray,:);
    kernel1=cell_oneD2twoD(ray,num_cell_x,num_cell_z);
    density=density+kernel1;
end


subplot(211)
imagesc(density,[-1000,1000]);title('density limit 1000');colormap jet;
subplot(212)
imagesc(density);title('density full');colormap jet;


