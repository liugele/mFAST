
%##########################################################################
velmodelfile=uigetfile('*.mat');
load(velmodelfile);
imagesc(x,z,vel);colormap jet;

%##########################################################################
rays_geom_file=uigetfile('*.mat');
load(rays_geom_file);
hold on;

num_obs=length(rays_geom);
for iobs=1:num_obs
    obs=rays_geom(iobs);
    plot(obs.shots_x,obs.shot_z,'b.');
    hold on;
    plot(obs.x,obs.z,'ro')
end


