%##########################################################################
% 2022 04 11
%##########################################################################
clear;
%##########################################################################
cur_dir=uigetdir;
cd(cur_dir);

%
inversion_result_file=uigetfile('*.mat');
load(inversion_result_file);



matfilename=uigetfile;
matfile_for_inversion_prefix=matfilename(1:end-11);
flag=input('save the figure or not : 1 for save and 0 for not');

for iter=1:10  
    
    disp(['I am iteration : ',num2str(iter)]);
    inversion_result=[matfile_for_inversion_prefix,'_iter_',num2str(iter),'.mat'];
    load(inversion_result);     
    
    figure;
    subplot(221);
    imagesc(initial_model.vel); colormap jet;colorbar; title(['initial model',num2str(iter)]);    
    subplot(222);
    imagesc(nodes_model.vel,[1500,4000]);  colormap jet;colorbar; title('inverted model');
    subplot(223);
    velsmo=velsmooth(nodes_model.vel,nodes_model.x,nodes_model.z,100);
    imagesc(velsmo,[1500,4000]);  colormap jet;colorbar; title('inverted model after smoothing');   
    subplot(224);    
    load('marmousi_forward_model.mat');
    imagesc(forward_model.vel);  colormap jet;colorbar; title('groundtruth model');
    
    if flag==1
    outfig=[matfile_for_inversion_prefix,'_iter_',num2str(iter),'.jpg'];
    saveas(gcf,outfig,'jpeg');
    end
    
    
end

% #########################################################################
