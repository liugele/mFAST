
velmodelfile=uigetfile('*.mat');
load(velmodelfile);
x=initial_model.x;
z=initial_model.z;
vel=initial_model.vel;

% figure;
% imagesc(x,z,vel);
% colormap jet;
% hold on
% [m,c]=contour(x,z,vel,[3000,3000]);hold on;
% c.LineWidth=1;

figure;
imagesc(vel);
colormap jet;
hold on;
[m,c]=contour(vel,[3000,4000]);hold on;
c.LineWidth=1;