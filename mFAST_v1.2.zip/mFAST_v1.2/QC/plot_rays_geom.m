%##########################################################################
%     obs.x=cur_obs_x;
%     obs.z=cur_obs_z;
%     obs.shots_x=xshots;
%     obs.shots_z=zshots;
%     obs.t_obs=fb;
%     obs.record_num=iobs;
%     obs.num_picks=length(fb);
%
%     rays_geom(iobs)=obs;
rays_geom_file=uigetfile('*.mat');
load(rays_geom_file);

if exist('rays_geom','var')
    num_obs=length(rays_geom);
    for iobs=1:num_obs
        obs=rays_geom(iobs);
        plot(obs.shots_x,obs.t_obs,'r.');
        hold on;
    end
else
    rays_geom=rays_geom_combined;
    num_obs=length(rays_geom);
    for iobs=1:num_obs/2
        obs=rays_geom(iobs);
        plot(obs.shots_x,obs.t_obs,'r.');
        hold on;
    end
    for iobs=num_obs/2:num_obs
        obs=rays_geom(iobs);
        plot(obs.shots_x,obs.t_obs,'b.');
        hold on;
    end
end






