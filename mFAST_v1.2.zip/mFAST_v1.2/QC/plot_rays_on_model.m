
%##########################################################################
%   plot the rays;
%   2021 05 31
%##########################################################################
%
close all;
cd(pwd);

model_file=uigetfile('select a model file please :');
load(model_file);

rays_file=uigetfile('select a ray file please :');
load(rays_file);


% plot velocity model
imagesc(initial_model.x,initial_model.z,initial_model.vel);
colormap jet;

hold on;

% plot the rays on the model
nrays=length(rays);
interval=input('ray interval please :');


for iray=1:interval:nrays
    ray=rays(iray);
    rayx=ray.x;
    rayz=ray.z;
    
    plot(rayx,rayz,'k.');
end
%################################ end ###################################

