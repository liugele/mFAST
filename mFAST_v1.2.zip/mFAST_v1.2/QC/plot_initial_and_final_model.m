%##########################################################################
% 2022 04 11
%##########################################################################
clear;
%##########################################################################
cur_dir=uigetdir;
cd(cur_dir);

%
inversion_result_file=uigetfile('*.mat');
load(inversion_result_file);

figure;
subplot(221);
imagesc(initial_model.vel); 
colormap jet;
colorbar; 
title(['initial model']);

%
inversion_result_file=uigetfile('*.mat');
load(inversion_result_file);

subplot(222);
imagesc(initial_model.vel); 
colormap jet;
colorbar; 
title(['final model'])



