function mFAST_tomo_no_regu_no_mask(rays_geom,initial_model,seafloor,forward_par,inversion_par,matfile_name_par)
%##########################################################################
% This function is used to do tomography.
% It could be applied in the conventional FAST and mirror FAST
% The differences between them lie in the preparation of the initial model
% and the seafloor.
% INPUTS:
% rays_geom :     A structure,include sx,sz,gx,gz,t  in m and seconds
% initial_model : A structure,several fields,vel, dx,dz,x,z,nx,nz
% seafloor :      A structure,seafloor.x and seafloor.z
% forward   parameters
% inversion parameters
% paramters related to the file names of oput
% 2022 02 23
% 2022 03 07 add laplacian regularization
% 2022 04 11
% regularization is delete
% mask is delete
% since the arrival times of direct water waves is used
% mask is not demand
% we choose to smooth the model after inversion and no regularization is
% added within the inversion
%##########################################################################

tic;
%##########################################################################
% prepare everthing for a tomography job 
% including: rays_geom/initial_model/seafloor/raytracing_par/inversion_par
% and savefile_name;
%############################
% load forward modeling paramter
% raytracing_par.dstep=10;
% raytracing_par.max_steps=20000;
raytracing_par.dstep=forward_par.dstep;
raytracing_par.max_steps=forward_par.max_steps;
raytracing_par.flag=forward_par.flag;
%############################
% load inversion parameter
% cell_dx=5000;
% cell_dz=250;
% flag=1;
% max_iter=10;
% tolerance=1;
% inversion_par.cell_dx=cell_dx;
% inversion_par.cell_dz=cell_dz;
% inversion_par.
cell_dx=inversion_par.cell_dx;
cell_dz=inversion_par.cell_dz;
max_iter=inversion_par.max_iter;
vmin=inversion_par.vmin;
vmax=inversion_par.vmax;
smooth_length=inversion_par.smooth_length;

%############################
% matfile_name
% matfile_for_rays='syn_rays_sm2';
% matfile_for_inversion='inversion_result_sm2';
% flag=0;
matfile_for_rays=matfile_name_par.for_rays;
matfile_for_inversion=matfile_name_par.for_inversion_model;
%############################

% prepare the seafloor
xmax=max(initial_model.x);
seafloor.x(end)=xmax;
%##########################################################################


%##########################################################################
for iter=1:max_iter

    disp(['now it is iteration : ',num2str(iter)]);

    %######################################################################
    % Compute ray-paths and travel-times based on initial-model
    forward_model=initial_model;
    [tcal,success_index,rays]=mFAST_raytracing(forward_model,rays_geom,raytracing_par,flag);
    save([matfile_for_rays,num2str(iter),'.mat'],'rays','tcal','success_index');
    %######################################################################

    %######################################################################
    % Construct the Jacobi matrix D
    [cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz);
    [D]=Bulid_jacobi_matrix_cells_simple(rays,cells_model,success_index,flag);
    %######################################################################

    %######################################################################
    % Build the right hand term
    % The right hand term corresponds to travel time differences
    [t_obs,t_cal,delta_t,t_xxx] = Build_the_delta_t(rays,rays_geom,success_index);

    %######################################################################
    % Solve the large-scale systems of linear equations
    % and obtain the delta model
    Delta_S = lsqr(D,delta_t);
    %######################################################################

    %######################################################################
    % One Dimension vector to two Dimension matrix
    twoD=cell_oneD2twoD(Delta_S,cells_model.num_cell_x,cells_model.num_cell_z);

    % update model in the format of cells
    cells_model.cell_vel=1./(1./cells_model.cell_vel+twoD);

    % update model in the format of nodes
    [inverted_model] = cells_model2nodes_model(cells_model,initial_model.dx,initial_model.dz);
    %######################################################################

    %######################################################################
    % post_inversion processing
    inverted_model_sm=inverted_model;
    vel0=inverted_model.vel;
    x=inverted_model.x;
    z=inverted_model.z;    
    vel0=velsmooth(vel0,x,z,smooth_length);
    vel0(vel0<vmin)=vmin;
    vel0(vel0>vmax)=vmax;
    inverted_model_sm.vel=vel0;    
    % #####################################################################
    
    %######################################################################
    % save the results related to current iteration
    % including initial_model used in this iteration
    %           nodes_model      inverted model from in this iteration
    %           nodes_model_sm   smoothing inverted model
    inversion_result=[matfile_for_inversion,'_iter_',num2str(iter),'.mat'];
    save(inversion_result,'t_obs','t_cal','delta_t','t_xxx','Delta_S','initial_model','inverted_model','inverted_model_sm');
    %######################################################################

    
    %######################################################################
    % prepare a new initial model based on the update model for next
    % iteration of tomograpy.
    initial_model=inverted_model_sm;
    %######################################################################

    %plot
    figure;
    subplot(311);
    imagesc(initial_model.vel,[vmin,vmax]); colormap jet;colorbar; title(['initial model iter = ',num2str(iter)]);
    subplot(312);
    imagesc(inverted_model.vel,[vmin,vmax]);  colormap jet;colorbar; title(['inverted model iter = ',num2str(iter)]);
    subplot(313);
    imagesc(inverted_model_sm.vel,[vmin,vmax]);  colormap jet;colorbar; title(['inverted model plus smoothing iter = ',num2str(iter)]);
end
toc;
end
