function mFAST_tomo(rays_geom,initial_model,seafloor,forward_par,inversion_par,matfile_name_par)

% This function is used to do tomography.
% It could be applied in the conventional FAST and mirror FAST
% The differences between them lie in the preparation of the initial model
% and the seafloor.
% INPUTS:
% rays_geom :     A structure,include sx,sz,gx,gz,t  in m and seconds
% initial_model : A structure,several fields,vel, dx,dz,x,z,nx,nz
% seafloor :      A structure,seafloor.x and seafloor.z
% forward   parameters
% inversion parameters
% paramters related to the file names of oput
% 2022 02 23
% 2022 03 07 add laplacian regularization
%##########################################################################
tic;

%##########################################################################
%############################
% load forward modeling paramter
% raytracing_par.dstep=10;
% raytracing_par.max_steps=20000;
raytracing_par.dstep=forward_par.dstep;
raytracing_par.max_steps=forward_par.max_steps;
raytracing_par.flag=forward_par.flag;
%############################
% load inversion parameter
% % cell_dx=5000;
% % cell_dz=250;
% % flag=1;
% % max_iter=10;
% % tolerance=1;
% % inversion_par.cell_dx=cell_dx;
% % inversion_par.cell_dz=cell_dz;
% % inversion_par.
cell_dx=inversion_par.cell_dx;
cell_dz=inversion_par.cell_dz;
max_iter=inversion_par.max_iter;
% tolerance=inversion_par.tolerance;

%############################
% matfile_name
% matfile_for_rays='dongsha_syn_rays_sm2';
% matfile_for_inversion='dongsha_inversion_result_sm2';
% flag=0;
matfile_for_rays=matfile_name_par.for_rays;
matfile_for_inversion=matfile_name_par.for_inversion_model;
%############################

% prepare the seafloor 
xmax=max(initial_model.x);
seafloor.x(end)=xmax;
%##########################################################################


%##########################################################################
for iter=1:max_iter
    
    disp(['now it is iteration : ',num2str(iter)]);
    
    %######################################################################
    % Compute ray-paths and travel-times based on initial-model
    forward_model=initial_model;
    [tcal,success_index,rays]=mFAST_raytracing(forward_model,rays_geom,raytracing_par,flag);
    save([matfile_for_rays,num2str(iter),'.mat'],'rays','tcal','success_index');
    %######################################################################    
    
    %######################################################################
    % Construct the Jacobi matrix D
    [cells_model] = nodes_model2cells_model(forward_model,cell_dx,cell_dz);
    [D]=Bulid_jacobi_matrix_cells_simple(rays,cells_model,success_index,flag);
    % Construct the mask matrix and then change it into a vector
    [mask_1d_vector]=Build_mask_index_1d_vector(cells_model,seafloor);
    % Apply the mask vector to the Jacobi matrix D
    num_row=size(D,1);
    for irow=1:num_row
        D(irow,:)=D(irow,:).*mask_1d_vector';
    end
    %######################################################################
    
    % Create a regularization matrix
    num_cell_x=cells_model.num_cell_x;
    num_cell_z=cells_model.num_cell_z;
    [regu_lap]=create_laplacian_matrix_reduced(num_cell_x,num_cell_z);
    
    % should add a regularization factor mu
    mu=1000;
    A=[D;mu*regu_lap];
    % The left hand matrix construction is finished
    %######################################################################    
    % AX=b
    
    %######################################################################
    % Build the right hand term
    % The right hand term corresponds to travel time differences
    [t_obs,t_cal,delta_t,t_xxx] = Build_the_delta_t(rays,rays_geom,success_index);    
    % The right hand term corresponds to laplacian regularization
    S0=cell_twoD2oneD(cells_model.cell_vel,num_cell_x,num_cell_z);
    Aug_t=-1*regu_lap*S0;
    Aug_t=zeros(size(Aug_t)); % This means only 2D smoothing is applied    
    
    % Constructing the right hand 
    DELTA_T=[delta_t;Aug_t];
    
    % Solve the large-scale systems of linear equations
    % and obtain the delta model
    Delta_S = lsqr(A,DELTA_T);
    %######################################################################    
    
    %######################################################################
    % One Dimension vector to two Dimension matrix
    twoD=cell_oneD2twoD(Delta_S,cells_model.num_cell_x,cells_model.num_cell_z);
    
    % update model in the format of cells
    cells_model.cell_vel=1./(1./cells_model.cell_vel+twoD);
    
    % update model in the format of nodes
    [nodes_model] = cells_model2nodes_model(cells_model,initial_model.dx,initial_model.dz);
    
    
    %######################################################################
    figure;
    subplot(121);
    imagesc(initial_model.vel); colormap jet;colorbar; title(['initial model iter = ',num2str(iter)]);
    subplot(122);
    imagesc(nodes_model.vel,[1500,8000]);  colormap jet;colorbar; title(['inverted model iter = ',num2str(iter)]);
    
    inversion_result=[matfile_for_inversion,'_iter_',num2str(iter),'.mat'];
    save(inversion_result,'t_obs','t_cal','delta_t','t_xxx','Delta_S','initial_model','nodes_model');
    
    
    % #####################################################################
    % prepare a new initial model based on the update model for next
    % iteration of tomograpy.
    vel0=nodes_model.vel;
    x=nodes_model.x;
    z=nodes_model.z;
    smooth_length=1000;
    vel0=velsmooth(vel0,x,z,smooth_length);
    dz=initial_model.dz;
    nx=initial_model.nx;
    for ix=1:nx
        xx=x(ix);
        seafloor_zz=interp1(seafloor.x,seafloor.z,xx);
        iseafloor_zz=fix(seafloor_zz/dz)+1;
        vel0(1:iseafloor_zz,ix)=1500;
    end
    vel0(vel0<1500)=1500;
    vel0(vel0>9000)=9000;
    initial_model.vel=vel0;
    % #####################################################################
    
    % To avoid menmory issues
    clear A
    clear D
    clear regu_lap   
    
    % #####################################################################
    
end
toc;
end
