function [t_obs,t_cal,delta_t,t_xxx] = Build_the_delta_t(rays,rays_geom,success_index)

% rays    calculated raypaths
%         ray.x=ray_x;
%         ray.z=ray_z;
%         ray.xs=xs;
%         ray.zs=zs;
%         ray.t_cal=cur_t_cal;
%         ray.t_obs=cur_t_obs;
%         ray.success=is_success;
% rays_geom,tcal,success_index  is used for QC
%##########################################################################
% ͳ���ж���������
nrays=length(rays);
disp(['There are ',num2str(nrays),'source-receiver pairs in the real data set']);

% QC
num_obs=length(rays_geom);
qc_nrays=0;
for i=1:num_obs
    cur_obs=rays_geom(i);
    npicks=cur_obs.num_picks;
    qc_nrays=qc_nrays+npicks;
end
if qc_nrays~=nrays
    error('the number of rays is not consistent');
end   


%##########################################################################
% ͳ���ж�������Ч����
neffective_rays=0;
for iray=1:nrays
    cur_ray=rays(iray);
    cur_success_index=cur_ray.success;
    neffective_rays=neffective_rays+cur_success_index;
end
qc_neffective_rays=sum(success_index);
if qc_neffective_rays~=neffective_rays
    error('the number of effective is not consistent');
end   
disp(['There are ',num2str(neffective_rays),' effective rays ']);


%##########################################################################
% ������Ч���߶�Ӧ������ʱ����delta_t
t_cal=zeros(neffective_rays,1);
t_obs=zeros(neffective_rays,1);
t_xxx=zeros(neffective_rays,1);   % the x coordinates of the effective rays

iray_effective=0;
for iray=1:nrays
    cur_ray=rays(iray);
    cur_success_index=cur_ray.success;
    neffective_rays=neffective_rays+cur_success_index;
    if cur_success_index==1
       iray_effective=iray_effective+1;  
       % disp(['ray ',num2str(iray),' of ', num2str(nrays),' is effective']);
       t_cal(iray_effective)=cur_ray.t_cal;
       t_obs(iray_effective)=cur_ray.t_obs;
       t_xxx(iray_effective)=cur_ray.xr;       
    end
end

delta_t=t_obs-t_cal;

end

     
    


