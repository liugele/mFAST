
% log
% 2022 05 16
% change x and z to  obs_x and obs_z to represent the location of OBS
% which will make it clear.