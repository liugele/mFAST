function [rays_geom] = prepare_inputs_rays_geom_from_ascii(ascii_file_name)

%##########################################################################
% FUNCTION : change the ascii format travel time table into
% the "rays_geom" structure used in the mFAST code
% INPUT : traveltime table file in the ascii file
% The ascii file contains five columns
% shot_x shot_z obs_x obs_z and traveltime in meters and in second
% OUTPUT: the rays_geom structure
%     obs.x=cur_obs_x;           % in m
%     obs.z=cur_obs_z;           % in m
%     obs.shots_x=shots_x;       % in m
%     obs.shots_z=shots_z;
%     obs.t_obs=t_obs;           % in second
%     obs.num_picks=cur_obs_picks;
%     obs.record_num=iobs;
%##########################################################################
disp(['please make sure that all the coordinates are in meter' ...
    'and traveltime is in second']);
right_format=input('1 for right and 0 for not :');
if right_format==0
    error('wrong units in the ascci file')
end


%##########################################################################
fb=load(ascii_file_name);
npicks=size(fb,1);
%##########################################################################
% determine how many OBSs are involved.
num_obs=1;
for ipick=2:npicks
    if fb(ipick,3)~=fb(ipick-1,3)  % a new OBS
        num_obs=num_obs+1;
    end
end
disp(['There are ',num2str(num_obs),' in total']);

%##########################################################################
% 缁熻OBS鐨勫潗鏍?
obs_x=zeros(num_obs,1);
obs_z=zeros(num_obs,1);
obs_x(1)=fb(1,3);
obs_z(1)=fb(1,4);
iobs=1;
for ipick=2:npicks
    if fb(ipick,3)~=fb(ipick-1,3)
        iobs=iobs+1;
        obs_x(iobs)=fb(ipick,3);  % in km
        obs_z(iobs)=fb(ipick,4);  % in km and minus
    end
end
plot(obs_x,obs_z,'*');
%##########################################################################


%##########################################################################
% 缁熻姣忎竴涓狾BS鐨勬嬀鍙栦釜鏁?
for iobs=1:num_obs

    cur_obs_x=obs_x(iobs);
    cur_obs_z=obs_z(iobs);

    % 缁熻褰撳墠OBS鐨勬嬀鍙栨儏鍐碉紝瀵规墍鏈夋嬀鍙栫偣寰幆銆?
    cur_obs_picks=0;
    for ipicks=1:npicks
        if fb(ipicks,3)==cur_obs_x
            cur_obs_picks=cur_obs_picks+1;
            shots_x(cur_obs_picks)=fb(ipicks,1);
            shots_z(cur_obs_picks)=fb(ipicks,2);
            t_obs(cur_obs_picks)=fb(ipicks,5);         % to ms
        end
    end

    % obs.x=cur_obs_x*1000;
    % obs.z=cur_obs_z*1000;
    obs.obs_x=cur_obs_x*1000;
    obs.obs_z=cur_obs_z*1000;
    obs.shots_x=shots_x;
    obs.shots_z=shots_z;
    obs.t_obs=t_obs;
    obs.num_picks=cur_obs_picks;
    obs.record_num=iobs;

    clear shots_x;
    clear shots_z;
    clear t_obs;

    rays_geom(iobs)=obs;
end


% QC
figure;
plot(fb(:,1),fb(:,5),'.');
flipy;

figure;
sum=0;
for iobs=1:num_obs
    obs=rays_geom(iobs);
    sum=sum+obs.num_picks;
    plot(obs.shots_x,obs.t_obs,'.');
    title(num2str(iobs));
    pause(1);
    disp(['i am obs ',num2str(iobs),' and i have ', num2str(obs.num_picks),' picks']);
end

disp(sum)
disp(npicks)


% save(matfile,'rays_geom');
%###############################end########################################
end