function [vel_with_water]=fun_create_a_model_with_water_layer(velmodel,x,z,seafloor_topo)
% Add a water layer on the existing velocity model. 
% This function will be useful when OBS survey is considered;
% 2022 02 18
%##########################################################################
% INPUT:
% velmodel : velocity model
% x        : the horizontal axis of velocity model (in meter);
% z        : the vertical   axis of velocity model (in meter);
% OUTPUT   :
% vel_with_water 
%          : a velocity model that has same size as the input velmodel         
%##########################################################################

%##########################################################################
% check the consistency between the seafloor topography file and the x axis
seafloor_x=seafloor_topo.x;
seafloor_z=seafloor_topo.z;
if seafloor_x==x
    disp('consistent');
else
    error('inconsistent');
end

%##########################################################################
vel_with_water=velmodel;
dz=z(2)-z(1);

[nz,nx]=size(velmodel);

for ix=1:nx
    zz=seafloor_z(ix);   
    izz=fix(zz/dz);
    vel_with_water(1:izz,ix)=1500;
end


% plot QC
figure;
subplot(211);
imagesc(x,z,velmodel);title('Original model');
subplot(212);
imagesc(x,z,vel_with_water);title('Original model');
end
%##########################################################################










