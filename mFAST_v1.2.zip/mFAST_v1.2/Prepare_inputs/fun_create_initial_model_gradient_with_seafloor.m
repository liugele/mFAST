
function [initial_model]=fun_create_initial_model_gradient_with_seafloor(dx,dz,xmax,zmax,vmin,vmax,seafloor)

%##########################################################################
% This function is used to create an intial model for tomography
% using the groundtruth seafloor as the input;
x=0:dx:xmax;
z=0:dz:zmax;
nx=length(x);
nz=length(z);
vel=zeros(nz,nx);
%##########################################################################
seafloor_x=seafloor.x;
seafloor_z=seafloor.z;
seafloor_x(end)=xmax;
%##########################################################################

for ix=1:nx
    xx=x(ix);
    seafloor_zz=interp1(seafloor_x,seafloor_z,xx);
    iseafloor_zz=fix(seafloor_zz/dz)+1;
    vel(1:iseafloor_zz,ix)=vmin;
    for iz=iseafloor_zz+1:nz
        vel(iz,ix)=vmin+(iz-iseafloor_zz)/(nz-iseafloor_zz)*(vmax-vmin);
    end
end
%##########################################################################

initial_model.dx=dx;
initial_model.dz=dz;
initial_model.x=x;
initial_model.z=z;
initial_model.vel=vel;
initial_model.nx=length(x);
initial_model.nz=length(z);
initial_model.seafloor=seafloor;

% 
% velsmo=min(min(vel))*ones(forward_model.nz,forward_model.nx);
% figure; imagesc(x,z,velsmo);colormap jet;title('inital_model model');
% save(outmatfile,'initial_model');
% log
% 2022 05 10
% the seafloor structure is stored within the initial_model