
function [seafloor]=prepare_inputs_seafloor_from_default_txt(txtfile,vel_x,flag)
% Make a regular seafloor based on a real seafloor bathymetric data
% INPUT :
% txtfile : This txtfile is from dongsha sea area.
% vel_x   : The destinated vel_x
% flag    : for plotting or not
% 
% OUTPUT:
% The seafloor information is stored in a MATLAB structure, called the
% seafloor
% The seafloor has two fields, x and z; (/m)
% Both x and z are in meters.
% #########################################################################

% #########################################################################
% load the real seafloor data in txt format
seafloor_txt=load(txtfile);
x0=seafloor_txt(:,1)*1000;
z0=seafloor_txt(:,2)*-1*1000;

% load the velocity model
xmax=max(vel_x);
xmin=min(vel_x);

% create a new x axis by multiplying the x0 with a simple scale
N=length(x0);
x1=linspace(xmin,xmax,N);

% interplate the z values to the new x axis
z = interp1 (x1, z0, vel_x, "spline");

% store the seafloor information 
seafloor.x=vel_x;
seafloor.z=z;

% plot 
if flag==1
figure;
subplot(311);
plot(x0,z0);title('Original seafloor topography');xlabel('m');ylabel('depth/m');
subplot(312);
plot(x1,z0);title('Scaled seafloor topography');xlabel('m');ylabel('depth/m');
subplot(313);
plot(vel_x,z);title('Final seafloor topography');xlabel('m');ylabel('depth/m');
end









