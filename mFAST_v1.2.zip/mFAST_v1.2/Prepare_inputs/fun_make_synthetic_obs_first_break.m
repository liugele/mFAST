
function [rays_geom]=fun_make_synthetic_obs_first_break(vel,x,z,OBSs_x,xshots,zshots,seafloor_topo,fb_txtfile_name)

% create ray_geom
% This ray_geom can be directly used in the mFAST toolbox
% unit related to spatial coordinate is m
% unit related to time coordinate is second
%##########################################################################

fid=fopen(fb_txtfile_name,'wb');
num_obs=length(OBSs_x);
dz=z(2)-z(1);
dx=x(2)-x(1);

figure;
for iobs=1:num_obs
    disp(['I am obs : ',num2str(iobs),' in ',num2str(num_obs)]);
    
    cur_obs_x=OBSs_x(iobs);
    cur_obs_z=interp1(seafloor_topo.x,seafloor_topo.z,cur_obs_x);       
    
    imagesc(x,z,vel);colormap jet; colorbar;hold on;
    plot(seafloor_topo.x,seafloor_topo.z);
    plot(cur_obs_x,cur_obs_z,'ro');
    plot(xshots,zshots,'*');
    %######################################################################   

    isx=fix(cur_obs_x/dx);
    isz=fix(cur_obs_z/dz);
    
    % compute the travel time field
    T=Mray(1./vel,[isz,isx],dx);    
    
    % extract first arrival time
    fb_index_rec=fix(zshots(1)/dz)+1;
    fb_index_shots=fix(xshots/dz)+1;
    fb=T(fb_index_rec,fb_index_shots);    
    
    % prepare the time table for output
    % which is suitable for PROFIT 
    xfb=xshots/1000;
    zfb=zshots*-1/1000;
    obs_xfb=cur_obs_x/1000*ones(size(xshots));
    obs_zfb=cur_obs_z/1000*ones(size(xshots))*-1;
    output=[xfb;zfb;obs_xfb;obs_zfb;fb];
    
    % print the time table to txtfile
    fprintf(fid,'%6.4f %6.4f %6.4f %6.4f %6.4f\n',output);    
    
    % prepare the time table for output
    % which is suitable for mFAST    
    obs.obs_x=cur_obs_x;
    obs.obs_z=cur_obs_z;
    obs.shots_x=xshots;
    obs.shots_z=zshots;
    obs.t_obs=fb;
    obs.record_num=iobs;
    obs.num_picks=length(fb);
    
    rays_geom(iobs)=obs;
    
end

fclose(fid);

% QC
figure;
fb=load(fb_txtfile_name);
plot(fb(:,1),fb(:,5),'r.');
%##########################################################################
%log
% 2022 05 16
% obs.x=cur_obs_x;
% obs.z=cur_obs_z;
% change into as:
% obs.obs_x=cur_obs_x;
% obs.obs_z=cur_obs_z;

