function [mask_1d_vector]=Build_mask_index_1d_vector(cells_model,seafloor)
%##########################################################################
% 2021 07 06 
% 建立mask 标识号
% 控制海底以上不更新
%##########################################################################

%##########################################################################
x=cells_model.x;
z=cells_model.z;
% dx_of_cell=cells_model.cell_dx;
% dz_of_cell=cells_model.cell_dz;
% x_orig=x(1);
% z_orig=z(1);
num_cell_x=cells_model.num_cell_x;
num_cell_z=cells_model.num_cell_z;
% Ncells=num_cell_x*num_cell_z;
%##########################################################################

% 海底深度信息
seafloor_x=seafloor.x;
seafloor_z=seafloor.z;
seafloor_x(end)=max(x);

%##########################################################################
mask_2d_cells=ones(num_cell_z,num_cell_x);
for icell_x=1:num_cell_x
    for icell_z=1:num_cell_z
        x0=x(icell_x);  x1=x(icell_x+1);
        z0=z(icell_z);  z1=z(icell_z+1);
        xm=0.5*(x0+x1);
        
        % 判断点（xm,z1)是否在海底之上
        seafloor_zm=interp1(seafloor_x,seafloor_z,xm);
        if z1<=seafloor_zm
            mask_2d_cells(icell_z,icell_x)=0;
        end
    end
end
%oneD=cell_twoD2oneD(twoD,num_cell_x,num_cell_z)
mask_1d_vector=cell_twoD2oneD(mask_2d_cells,num_cell_x,num_cell_z);
end
        
        
   